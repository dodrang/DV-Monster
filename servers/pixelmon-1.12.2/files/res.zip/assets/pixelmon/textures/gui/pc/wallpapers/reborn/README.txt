These wallpapers are kindly offered by the Pokemon fan-game Reborn (rebornevo.com), created by Amethyst and adapted by happyzlife.
Show them some love!